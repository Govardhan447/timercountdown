let timerDigitsEle = document.getElementById("timerDigits");

let hourDigitEle = document.getElementById("hourDigit");

let minuteDigitEle = document.getElementById("minuteDigit");
let secDigitEle = document.getElementById("secDigit");

let milliSecDigitE = document.createElement("span")


let startBtnEle = document.getElementById("startBtn");

let stopBtnEle = document.getElementById("stopBtn");
let resetBtnEle = document.getElementById("resetBtn");

let count = 0;
let uniqueId = null;

function startTimer() {
    uniqueId = setInterval(function() {
        count = count + 1;
        milliSecDigitE.textContent = ":" + count;
    }, 100);
}

function stopTimer() {
    clearInterval(uniqueId);
    milliSecDigitE.textContent = ":" + count;
}

function resetTimer() {
    clearInterval(uniqueId);
    count = 0;
    milliSecDigitE.textContent = "";
}

startBtnEle.addEventListener("click", startTimer);
stopBtnEle.addEventListener("click", stopTimer);

resetBtnEle.addEventListener("click", resetTimer);


timerDigitsEle.appendChild(milliSecDigitE);